To start thine website, Ye must open thine file with thee name called "index.html"
Thy shall open a browser. 
For ye, I recommded a browser for ye shall use, tis the beast called "Google Chrome" 